# Imperial Reader

Imperial Reader is an Android app for discovering and reading manga, manhwa, manhua, comics, EPUB books, and web novels. It brings online catalogs, downloaded chapters, and your own local files together in one library.

> Online catalogs are third-party sites and services. Their availability, content, and site layouts can change; a source that stops working may need to be disabled or replaced.

## Get started quickly

### Install the app

1. Open the [GitHub Releases](https://github.com/Kvngz3n0/ImperialreaderApp/releases) page and download the APK from the latest release.
2. Open the APK on your Android device and approve installation from that source if Android asks.
3. Launch **Imperial Reader**. The app needs internet access to browse online catalogs. Notification permission is optional and may be requested on Android 13 and newer.

The app supports Android 8.0 (API 26) and later.

### Find and read something

1. Open **Browse**. The **Sources** tab lists manga and comic sites; the **Extensions** tab lists book and web-novel catalogs.
2. Open a source or catalog, browse popular titles, or use search. In a manga source, choose **Latest** to browse recent updates.
3. Open a title. Add it to your library, then tap **Start** or a chapter to read.
4. Use the **Library**, **Updates**, and **History** tabs to return to saved titles, check for new chapters, and continue recent reading.

For manga and comics, tap the reader to show controls. Choose left-to-right, right-to-left, or vertical/webtoon mode in the reader; your default mode and other reading preferences are in **More → Settings**.

### Read your own files

1. In **More → Storage folder**, choose a folder and grant access. Imperial Reader creates `local/`, `downloads/`, and `autobackup/` inside it.
2. Put local files under `local/<Title>/`. Each archive, PDF, EPUB, PSD, PSB, CLIP, or image subfolder is treated as a chapter. PSD, PSB, and CLIP files use an embedded flattened preview when available; layered editing is not supported.
3. Choose **More → Scan local library** to import or refresh your local titles.

PDFs open in a paged reader with page navigation and saved progress. You can also browse Project Gutenberg and Internet Archive for EPUBs and PDFs, or browse supported web-novel catalogs including NovelArrow and RoliaScans Novels. Downloaded web-novel chapters can be packaged as an EPUB. EPUB reading includes adjustable text size, dark/sepia/light themes, text-to-speech, and a seekable chapter progress bar.

## What it can do

### Discover and search

- Browse manga, manhwa, manhua, webcomics, and western comics from built-in sources, including WEBTOON, Hentai Cosplay XXX, Roliascans, RavenScans.org, AllPornComic, Pawchive, and Comix.to.
- Browse online EPUB and web-novel catalogs, including Project Gutenberg, Internet Archive, Royal Road, NovelArrow, and supported web-novel sites. Internet Archive results include readable EPUB and PDF files.
- Search across online catalogs from **Browse** or from the library's global search. Global search preserves same-title results from separate catalogs, combines manga sources when requested, and offers optional genre/tag and artist filters.
- Global Search runs up to five source operations at a time, streams results as each source completes, retries temporary network failures, and lets you retry failed sources without restarting. Its progress summary reports the total incomplete-source count; **Show only sources with results** hides sources with no results.
- Comick uses its public browsing API and shared app networking. Actual Cloudflare challenges are distinguished from ordinary HTTP and network errors; if automatic resolution is unsuccessful, open the source in WebView to complete the challenge and retry.
- Add a custom manga site by name and URL. Imperial Reader attempts to detect supported site engines when you first open it.
- Enable or disable sources and open a source in the in-app WebView. The WebView can help with sites that require a Cloudflare challenge.
- Adult (18+) sources and ratings are hidden by default and can be enabled in Settings after age confirmation.

### Organize your library

- Save titles to your library and group them into custom categories.
- Search, sort, and filter library entries, including by unread chapters, bookmarks, and downloaded chapters.
- Select multiple titles to move them between categories or remove them from the library.
- See unread, downloaded/local, and new-chapter counts, with display options in Settings. The **Updates** tab badge shows unseen chapter updates and clears when you open the tab; updates remain listed and are dimmed until new chapters arrive.
- Set a custom cover for a title from its details screen. Tap the cover in the details header to view it full-screen and save it to Pictures.
- The details/chapter list temporarily samples accent colors from the title cover and returns to the app theme when closed.
- Refresh a title's chapter list or update the library for new chapters. Library refresh checks online entries with up to 10 concurrent source operations, then scans local entries. Scheduled and on-app-start refreshes use persistent foreground WorkManager jobs so they can continue when the app is backgrounded or closed.

### Read, track, and download

- Read online or downloaded manga/comic chapters in left-to-right, right-to-left, or vertical/webtoon layouts. Animated GIF pages and Pawchive MP4 posts are supported.
- Resume reading progress, move between chapters, and optionally use screen-edge taps or volume keys for page navigation.
- Enable **More → Settings → Skip duplicate chapters and gaidens** to prefer the current scanlation when moving to the next chapter. Duplicate chapter variants and intervening gaidens are marked read; when the current scanlation has no further unread chapters, navigation can continue with another scanlation.
- Bookmark chapters, mark chapters read or unread, and see reading history. Incognito mode disables reading-history entries.
- Queue chapter downloads, follow the queue in **More**, and read downloaded chapters offline. Large multi-chapter downloads are grouped by title and can be paused or resumed together.
- Browse and read EPUBs and web novels, seek between EPUB sections, resume saved chapter/page progress, adjust text size and theme, and listen with device text-to-speech.
- Optionally show only downloaded titles in the library.

### Local files and backups

- Read online PSD and PSB chapter pages by converting their flattened composite previews to cached images, including downloaded pages.
- Import local image folders and CBZ, ZIP, CBR, RAR, PDF, EPUB, PSD, PSB, and CLIP files as library titles. PSD, PSB, and CLIP reading uses embedded previews when available.
- Read local titles from the library and refresh the scan when files change.
- Choose where downloads and local files are stored; without a selected folder, the app uses private app storage.
- Export or restore a JSON backup containing library titles, categories, chapter read/bookmark/progress state, and history. Restore merges with the current library rather than deleting it.
- Create automatic backups manually or let the app run them periodically; it keeps a rolling set of the five most recent automatic backups.

## Settings

Open **More → Settings** to configure:

- Default manga/comic reading direction, screen-on behavior, fullscreen mode, edge taps, and volume-key navigation.
- Optional duplicate-chapter and gaiden skipping while preserving the current scanlation when possible.
- Library grid columns, unread/download badges, and refreshing the library on app start.
- Cover extraction for local entries.
- Visibility of adult sources and ratings.
- Clearing cached images/archive data or saved site cookies.

The EPUB reader has its own text-size controls, theme selector, seekable chapter progress, and text-to-speech button.

## Build from source

### Requirements

- Android SDK platform 34 and Android build tools 34.0.0.
- JDK 17.
- Gradle 8.2.

### Build a debug APK

From the repository root:

```sh
cd android/ImperialReader
gradle assembleDebug
```

The APK is written to `android/ImperialReader/app/build/outputs/apk/debug/`. A GitHub Actions workflow also builds a debug APK when Android project files are pushed to `main` or `master`, or when manually dispatched; the uploaded workflow artifact is retained for 14 days.

To build a release APK, run `gradle assembleRelease` from `android/ImperialReader`. Without a configured signing key, Gradle produces an unsigned release APK.

## Repository layout

- `android/ImperialReader/` — Android application source and Gradle build.
- `.github/workflows/build-imperialreader-apk.yml` — repository APK build workflow.
- `artifacts/`, `lib/`, and `scripts/` — additional workspace artifacts and tooling.

## Notes

- The app depends on third-party websites and public catalog APIs. Site changes, network availability, regional restrictions, or anti-bot checks can affect browsing and downloads.
- Use custom sources only with sites and material you are authorized to access. Adult sources are intended only for adults 18 and older.
- Imperial Reader is an independent reader app and is not affiliated with the third-party catalogs it can access.
