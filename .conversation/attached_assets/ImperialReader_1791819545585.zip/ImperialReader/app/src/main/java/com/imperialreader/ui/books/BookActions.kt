package com.imperialreader.ui.books

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.imperialreader.data.book.BookItem
import com.imperialreader.data.book.BookSource
import com.imperialreader.data.book.EpubBuilder
import com.imperialreader.data.book.BookSources
import com.imperialreader.data.db.LOCAL_SOURCE_ID
import com.imperialreader.data.storage.LocalScanner
import com.imperialreader.ui.details.MangaDetailsActivity
import com.imperialreader.util.app
import com.imperialreader.util.sanitize
import com.imperialreader.util.toast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.IOException

/** Shared "what do you want to do with this EPUB" flow used by Browse → Books and Global search. */
object BookActions {

    fun show(activity: AppCompatActivity, item: BookItem) {
        val details = buildString {
            append(item.author ?: "Unknown author")
            append("\nSource: ").append(item.sourceName)
            item.description?.takeIf { it.isNotBlank() }?.let { append("\n\n").append(it.take(500)) }
        }
        MaterialAlertDialogBuilder(activity)
            .setTitle(item.title)
            .setMessage(details)
            .apply {
                val source = BookSources.get(item.sourceId)
                if (source?.isWebNovel == true) {
                    setPositiveButton("Download as EPUB…") { _, _ -> chooseChapters(activity, item, source) }
                } else {
                    setPositiveButton("Download & add to library") { _, _ -> addToLibrary(activity, item) }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun chooseChapters(activity: AppCompatActivity, item: BookItem, source: BookSource) {
        val options = arrayOf("First 25 chapters", "First 100 chapters", "First 300 chapters", "All chapters")
        val counts = intArrayOf(25, 100, 300, Int.MAX_VALUE)
        MaterialAlertDialogBuilder(activity)
            .setTitle("Download “${item.title}”")
            .setItems(options) { _, which -> downloadNovel(activity, item, source, counts[which]) }
            .show()
    }

    /** Fetches the chapters one by one (politely), builds an EPUB, saves it in local/ and opens the entry. */
    private fun downloadNovel(activity: AppCompatActivity, item: BookItem, source: BookSource, limit: Int) {
        var job: Job? = null
        val dialog = MaterialAlertDialogBuilder(activity)
            .setTitle(item.title)
            .setMessage("Reading chapter list…")
            .setCancelable(false)
            .setNegativeButton("Cancel") { _, _ -> job?.cancel() }
            .show()
        job = activity.lifecycleScope.launch {
            try {
                val list = source.chapters(item).take(limit)
                if (list.isEmpty()) throw IOException("No chapters found. This site may need a browser to list them.")
                val pages = ArrayList<Pair<String, String>>()
                list.forEachIndexed { i, ch ->
                    dialog.setMessage("Chapter ${i + 1} of ${list.size}\n${ch.title}")
                    val html = try {
                        source.chapterHtml(ch)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        "<p>(This chapter could not be downloaded: ${e.message})</p>"
                    }
                    pages.add(ch.title to html)
                    delay(250)
                }
                dialog.setMessage("Building EPUB…")
                val id = withContext(Dispatchers.IO) { saveBuilt(activity.applicationContext, item, pages) }
                dialog.dismiss()
                activity.startActivity(MangaDetailsActivity.intent(activity, id))
            } catch (e: CancellationException) {
                dialog.dismiss()
                activity.toast("Download cancelled")
                throw e
            } catch (e: Exception) {
                dialog.dismiss()
                activity.toast("Download failed: ${e.message}")
            }
        }
    }

    private suspend fun saveBuilt(ctx: Context, item: BookItem, chapters: List<Pair<String, String>>): Long {
        val app = ctx.app
        val local = app.storage.localDir() ?: throw IOException("Storage is not available")
        val folderName = item.title.sanitize().take(100)
        val dir = app.storage.findOrCreateDir(local, folderName) ?: throw IOException("Cannot create folder")
        val fileName = "$folderName.epub"
        dir.findFile(fileName)?.delete() // a re-download replaces the old file instead of making a copy
        val file = dir.createFile("application/epub+zip", fileName) ?: throw IOException("Cannot create file")
        val out = ctx.contentResolver.openOutputStream(file.uri, "w") ?: throw IOException("Cannot write file")
        out.use { EpubBuilder.build(item.title, item.author, chapters, it) }
        saveCover(ctx, item, dir)
        LocalScanner(ctx).scan()
        return app.db.mangaDao().find(LOCAL_SOURCE_ID, folderName)?.id ?: throw IOException("Saved, but the library could not import it")
    }

    private fun saveCover(ctx: Context, item: BookItem, dir: androidx.documentfile.provider.DocumentFile) {
        val cover = item.coverUrl ?: return
        try {
            dir.findFile("cover.jpg")?.delete()
            ctx.app.network.client.newCall(Request.Builder().url(cover).build()).execute().use { resp ->
                if (resp.isSuccessful) {
                    val c = dir.createFile("image/jpeg", "cover.jpg")
                    if (c != null) ctx.contentResolver.openOutputStream(c.uri, "w")?.use { resp.body!!.byteStream().copyTo(it) }
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun addToLibrary(activity: AppCompatActivity, item: BookItem) {
        activity.toast("Downloading “${item.title}”…")
        activity.lifecycleScope.launch {
            try {
                val id = withContext(Dispatchers.IO) { download(activity.applicationContext, item) }
                activity.startActivity(MangaDetailsActivity.intent(activity, id))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                activity.toast("Download failed: ${e.message}")
            }
        }
    }

    /** Saves the EPUB as local/<Title>/<Title>.epub, rescans, and returns the library entry id. */
    private suspend fun download(ctx: Context, item: BookItem): Long {
        val app = ctx.app
        val local = app.storage.localDir() ?: throw IOException("Storage is not available")
        val folderName = item.title.sanitize().take(100)
        val dir = app.storage.findOrCreateDir(local, folderName) ?: throw IOException("Cannot create folder")

        val url = (BookSources.get(item.sourceId) ?: throw IOException("Unknown catalog")).resolveEpubUrl(item)
        val fileName = "$folderName.epub"
        dir.findFile(fileName)?.delete()
        val file = dir.createFile("application/epub+zip", fileName) ?: throw IOException("Cannot create file")

        app.network.client.newCall(Request.Builder().url(url).build()).execute().use { resp ->
            if (!resp.isSuccessful) {
                file.delete()
                throw IOException("HTTP ${resp.code}")
            }
            val out = ctx.contentResolver.openOutputStream(file.uri, "w") ?: throw IOException("Cannot write file")
            out.use { resp.body!!.byteStream().copyTo(it) }
        }
        if (file.length() < 1024) {
            file.delete()
            throw IOException("The download was empty")
        }

        saveCover(ctx, item, dir)

        LocalScanner(ctx).scan()
        return app.db.mangaDao().find(LOCAL_SOURCE_ID, folderName)?.id
            ?: throw IOException("Downloaded, but the library could not import it")
    }
}
